<?php
	session_start();
	if(!isset($_SESSION['logged']))
	{
		header('Location: index.php');
		exit();
	}
	
	
	session_unset();
	
	header('Location: index.php');

	
?>