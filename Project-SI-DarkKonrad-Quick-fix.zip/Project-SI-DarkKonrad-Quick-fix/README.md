------------> PROSZĘ PRZECZYTAĆ <-------------


Standardowo " U mnie działa" 

Komentarze działają, zalogowani mogą je dodawać niezalogowani nie mogą i wyświetla im się komunikat o konieczności logowania.
Na stronie głównej będą się wyświetlać 5 najnowszych artykółów ( Tytuł + wstęp). Kliknięcie na Tytuł przenosi do strony z pełnym artykułem i komentarzami. Teraz w prawym górnym rogu zalogowany użytkownik bedzie widział swój login. Jest też turbofix dla edycji użytkowników, bo wcześniej przekierowywał do edycji artykółów ale już fixed + dodany przycisk powrotu. 
